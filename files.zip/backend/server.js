// ...existing imports and app setup...

// Endpoint to create a new repo
app.post('/api/repos', (req, res) => {
  const { name, owner, description } = req.body;
  if (!name || !owner) return res.status(400).json({ error: 'Name and owner required' });
  const newRepo = { id: uuidv4(), name, owner, description: description || '', stars: 0 };
  repos.push(newRepo);
  res.status(201).json(newRepo);
});

// Endpoint to create a new issue
app.post('/api/repos/:id/issues', (req, res) => {
  const { title, author } = req.body;
  if (!title || !author) return res.status(400).json({ error: 'Title and author required' });
  const newIssue = { id: uuidv4(), repoId: req.params.id, title, author, status: 'open' };
  issues.push(newIssue);
  res.status(201).json(newIssue);
});

// Endpoint to create a new PR
app.post('/api/repos/:id/prs', (req, res) => {
  const { title, author } = req.body;
  if (!title || !author) return res.status(400).json({ error: 'Title and author required' });
  const newPR = { id: uuidv4(), repoId: req.params.id, title, author, status: 'open' };
  prs.push(newPR);
  res.status(201).json(newPR);
});

// Simple login endpoint (not secure, demo only)
app.post('/api/login', (req, res) => {
  const { username } = req.body;
  const user = users.find(u => u.username === username);
  if (user) {
    res.json({ success: true, user });
  } else {
    res.status(401).json({ success: false, error: 'User not found' });
  }
});

// Basic file listing (pretend files for demo)
app.get('/api/repos/:id/files', (req, res) => {
  res.json([
    { name: 'README.md', size: 123, type: 'file' },
    { name: 'src/', size: 0, type: 'folder' }
  ]);
});

// Activity feed (demo)
app.get('/api/activity', (req, res) => {
  res.json([
    { id: 'a1', type: 'repo_created', repo: 'hello-world', by: 'Sol-m3nace', timestamp: Date.now() },
    { id: 'a2', type: 'issue_created', repo: 'hello-world', by: 'Sol-m3nace', issue: 'Bug: Fix login', timestamp: Date.now() }
  ]);
});