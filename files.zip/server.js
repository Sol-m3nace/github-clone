const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

const repos = [
  { id: 1, name: 'hello-world', owner: 'Sol-m3nace', stars: 10 },
  { id: 2, name: 'awesome-project', owner: 'Sol-m3nace', stars: 25 }
];

app.get('/api/repos', (req, res) => {
  res.json(repos);
});

app.listen(3001, () => console.log('API running on http://localhost:3001'));