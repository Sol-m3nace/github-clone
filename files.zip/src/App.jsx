import React, { useEffect, useState } from 'react';

function App() {
  const [repos, setRepos] = useState([]);

  useEffect(() => {
    fetch('http://localhost:3001/api/repos')
      .then(res => res.json())
      .then(setRepos);
  }, []);

  return (
    <div style={{ fontFamily: 'system-ui', margin: '2rem' }}>
      <h1 style={{ color: '#24292f' }}>GitHub Clone</h1>
      <h2>Your Repositories</h2>
      <ul>
        {repos.map(repo => (
          <li key={repo.id}>
            <strong>{repo.name}</strong> by {repo.owner} ⭐ {repo.stars}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;