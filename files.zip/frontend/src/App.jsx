import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Home from './Home';
import RepoDetail from './RepoDetail';
import UserProfile from './UserProfile';

function App() {
  return (
    <BrowserRouter>
      <nav style={{ padding: "1rem", background: "#24292f" }}>
        <Link to="/" style={{ color: "#fff", textDecoration: "none", fontWeight: "bold" }}>GitHub Clone</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/repo/:id" element={<RepoDetail />} />
        <Route path="/user/:username" element={<UserProfile />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;