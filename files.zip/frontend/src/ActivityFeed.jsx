import React, { useEffect, useState } from 'react';

function ActivityFeed() {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    fetch('http://localhost:3001/api/activity')
      .then(res => res.json())
      .then(setEvents);
  }, []);

  return (
    <div style={{ margin: '2rem' }}>
      <h3>Activity Feed</h3>
      <ul>
        {events.map(ev => (
          <li key={ev.id}>
            [{new Date(ev.timestamp).toLocaleString()}] {ev.type} in {ev.repo} by {ev.by}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ActivityFeed;