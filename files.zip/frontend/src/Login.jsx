import React, { useState } from 'react';

function Login({ onLogin }) {
  const [username, setUsername] = useState('');
  const [msg, setMsg] = useState('');

  const handleSubmit = async e => {
    e.preventDefault();
    const res = await fetch('http://localhost:3001/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username })
    });
    const data = await res.json();
    if (data.success) {
      setMsg('');
      onLogin(data.user);
    } else {
      setMsg(data.error);
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ margin: '2rem' }}>
      <h3>Login</h3>
      <input value={username} onChange={e => setUsername(e.target.value)} placeholder="Username" required />
      <button type="submit">Login</button>
      <div>{msg}</div>
    </form>
  );
}

export default Login;