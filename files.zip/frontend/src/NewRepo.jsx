import React, { useState } from 'react';

function NewRepo() {
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [msg, setMsg] = useState('');

  const handleSubmit = async e => {
    e.preventDefault();
    const res = await fetch('http://localhost:3001/api/repos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, owner: 'Sol-m3nace', description: desc })
    });
    const data = await res.json();
    setMsg(data.error ? data.error : `Repo ${data.name} created!`);
    setName('');
    setDesc('');
  };

  return (
    <form onSubmit={handleSubmit} style={{ margin: '2rem' }}>
      <h3>Create a New Repository</h3>
      <input value={name} onChange={e => setName(e.target.value)} placeholder="Repo name" required />
      <input value={desc} onChange={e => setDesc(e.target.value)} placeholder="Description" />
      <button type="submit">Create</button>
      <div>{msg}</div>
    </form>
  );
}

export default NewRepo;