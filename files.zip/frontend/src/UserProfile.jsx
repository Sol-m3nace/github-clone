import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

function UserProfile() {
  const { username } = useParams();
  const [user, setUser] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:3001/api/users/${username}`)
      .then(res => res.json())
      .then(setUser);
  }, [username]);

  if (!user) return <div>Loading...</div>;

  return (
    <div style={{ margin: '2rem' }}>
      <h2>{user.username}</h2>
      <img src={user.avatar} alt={user.username} width={100} />
      <p>User ID: {user.id}</p>
    </div>
  );
}

export default UserProfile;