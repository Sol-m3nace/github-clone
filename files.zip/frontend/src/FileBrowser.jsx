import React, { useEffect, useState } from 'react';

function FileBrowser({ repoId }) {
  const [files, setFiles] = useState([]);

  useEffect(() => {
    fetch(`http://localhost:3001/api/repos/${repoId}/files`)
      .then(res => res.json())
      .then(setFiles);
  }, [repoId]);

  return (
    <div>
      <h3>Files</h3>
      <ul>
        {files.map(file => (
          <li key={file.name}>{file.type === 'folder' ? '📁' : '📄'} {file.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default FileBrowser;