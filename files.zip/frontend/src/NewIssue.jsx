import React, { useState } from 'react';

function NewIssue({ repoId }) {
  const [title, setTitle] = useState('');
  const [msg, setMsg] = useState('');

  const handleSubmit = async e => {
    e.preventDefault();
    const res = await fetch(`http://localhost:3001/api/repos/${repoId}/issues`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, author: 'Sol-m3nace' })
    });
    const data = await res.json();
    setMsg(data.error ? data.error : `Issue "${data.title}" created!`);
    setTitle('');
  };

  return (
    <form onSubmit={handleSubmit} style={{ margin: '1rem 0' }}>
      <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Issue title" required />
      <button type="submit">Add Issue</button>
      <div>{msg}</div>
    </form>
  );
}

export default NewIssue;