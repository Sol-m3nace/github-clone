import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';

function RepoDetail() {
  const { id } = useParams();
  const [repo, setRepo] = useState(null);
  const [issues, setIssues] = useState([]);
  const [prs, setPRs] = useState([]);

  useEffect(() => {
    fetch(`http://localhost:3001/api/repos/${id}`).then(res => res.json()).then(setRepo);
    fetch(`http://localhost:3001/api/repos/${id}/issues`).then(res => res.json()).then(setIssues);
    fetch(`http://localhost:3001/api/repos/${id}/prs`).then(res => res.json()).then(setPRs);
  }, [id]);

  if (!repo) return <div>Loading...</div>;

  return (
    <div style={{ margin: '2rem' }}>
      <h2>{repo.name}</h2>
      <p>{repo.description}</p>
      <p>Owner: <Link to={`/user/${repo.owner}`}>{repo.owner}</Link></p>
      <p>Stars: {repo.stars}</p>

      <h3>Issues</h3>
      <ul>
        {issues.map(issue => (
          <li key={issue.id}>{issue.title} by {issue.author} [{issue.status}]</li>
        ))}
      </ul>

      <h3>Pull Requests</h3>
      <ul>
        {prs.map(pr => (
          <li key={pr.id}>{pr.title} by {pr.author} [{pr.status}]</li>
        ))}
      </ul>
    </div>
  );
}

export default RepoDetail;