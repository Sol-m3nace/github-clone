import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

function Home() {
  const [repos, setRepos] = useState([]);

  useEffect(() => {
    fetch('http://localhost:3001/api/repos')
      .then(res => res.json())
      .then(setRepos);
  }, []);

  return (
    <div style={{ margin: '2rem' }}>
      <h2>Your Repositories</h2>
      <ul>
        {repos.map(repo => (
          <li key={repo.id}>
            <Link to={`/repo/${repo.id}`}>{repo.name}</Link> — {repo.description} ⭐ {repo.stars}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Home;