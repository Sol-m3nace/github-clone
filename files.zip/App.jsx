import React, { useEffect, useState } from 'react';
function App() {
  const [repos, setRepos] = useState([]);
  useEffect(() => {
    fetch('/api/repos').then(res => res.json()).then(setRepos);
  }, []);
  return (
    <div>
      <h1>Your Repositories</h1>
      <ul>
        {repos.map(repo => <li key={repo.name}>{repo.name} by {repo.owner}</li>)}
      </ul>
    </div>
  );
}
export default App;